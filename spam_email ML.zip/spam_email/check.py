import pandas as pd

try:
    df = pd.read_csv('spam.csv')
    print("Your spam.csv file has these columns:")
    print(df.columns.tolist()) # .tolist() makes it easier to read
except FileNotFoundError:
    print("Error: spam.csv not found.")
except Exception as e:
    print(f"An error occurred: {e}")