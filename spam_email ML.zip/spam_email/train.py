import pandas as pd
import os
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression  # Using the powerful model
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import seaborn as sns             # For the graph
import matplotlib.pyplot as plt   # For the graph
import joblib

# --- Load the Data ---
try:
    df = pd.read_csv('spam.csv')
except FileNotFoundError:
    print("Error: Dataset file 'spam.csv' not found.")
    exit()

# --- Clean and Prepare Data ---
# This uses the column names from your final dataset
try:
    df = df[['label', 'text']]
except KeyError:
    print("\n--- ERROR ---")
    print("Could not find 'label' or 'text' columns.")
    exit()

df.columns = ['label', 'message']
df.dropna(inplace=True)

print("Data loaded successfully:")
print(df.head())
print("\nData distribution:")
print(df['label'].value_counts())

# --- Preprocess and Split Data ---
df['label'] = df['label'].map({'ham': 0, 'spam': 1})
X = df['message']
y = df['label']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20, random_state=42)

print(f"\nTotal messages: {len(X)}")
print(f"Training messages: {len(X_train)}")
print(f"Testing messages: {len(X_test)}")

# --- Feature Extraction (Turn Text into Numbers) ---
tfidf_vectorizer = TfidfVectorizer(stop_words='english', lowercase=True)
X_train_tfidf = tfidf_vectorizer.fit_transform(X_train)
X_test_tfidf = tfidf_vectorizer.transform(X_test)

print(f"\nShape of TF-IDF matrix (training): {X_train_tfidf.shape}")

# --- Train Your Model ---
model = LogisticRegression(random_state=42, max_iter=1000)

print("\nTraining the new, more powerful model...")
model.fit(X_train_tfidf, y_train)
print("Model trained successfully!")

# --- Evaluate Your Model ---
y_pred = model.predict(X_test_tfidf)
accuracy = accuracy_score(y_test, y_pred)
print(f"\n--- Model Evaluation ---")
print(f"Accuracy: {accuracy * 100:.2f}%")
print("\nClassification Report:")
print(classification_report(y_test, y_pred, target_names=['Ham (0)', 'Spam (1)']))

print("\nConfusion Matrix:")
cm = confusion_matrix(y_test, y_pred)
print(cm)

# --- THIS IS THE GRAPH CODE ---
print("\nGenerating confusion matrix graph...")
plt.figure(figsize=(8, 6))  # Set the figure size
# Create the heatmap
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
            xticklabels=['Ham (0)', 'Spam (1)'],
            yticklabels=['Ham (0)', 'Spam (1)'])
plt.xlabel('Predicted Label')
plt.ylabel('Actual Label')
plt.title('Confusion Matrix Heatmap (Test Set)')
# This command opens the graph in a new window
plt.show()
# --- END OF GRAPH CODE ---


# --- Save the Model and Vectorizer ---
folder_name = "saved_model_files"
if os.path.exists(folder_name):
    print(f"\nFolder '{folder_name}' already exists. Overwriting model files.")
else:
    os.makedirs(folder_name)
    print(f"\nSuccessfully created folder: '{folder_name}'")

vectorizer_path = os.path.join(folder_name, 'spam_vectorizer.joblib')
model_path = os.path.join(folder_name, 'spam_model.joblib')
joblib.dump(tfidf_vectorizer, vectorizer_path)
joblib.dump(model, model_path)
print(f"Vectorizer saved to: {vectorizer_path}")
print(f"Model saved to: {model_path}")

