import joblib
import os

# --- Load the "Already Built" Model ---

# Define the folder and file paths
folder_name = "saved_model_files"
vectorizer_path = os.path.join(folder_name, 'spam_vectorizer.joblib')
model_path = os.path.join(folder_name, 'spam_model.joblib')

print("Loading pre-trained model and vectorizer...")

# 1. Load the vectorizer and model
try:
    vectorizer = joblib.load(vectorizer_path)
    model = joblib.load(model_path)
    print("Model loaded successfully!")
except FileNotFoundError:
    print("Error: Model files not found.")
    print(f"Make sure '{folder_name}' exists and contains the .joblib files.")
    exit()

# 2. Create a function to make predictions
def classify_message(message):
    message_tfidf = vectorizer.transform([message])
    prediction = model.predict(message_tfidf)
    return "Spam" if prediction[0] == 1 else "Not Spam (Ham)"

# --- This is the new interactive part ---
print("\n--- Spam Detector is Ready (Type 'exit' to quit) ---")

# 3. Create a loop that runs forever
while True:
    # 4. Ask the user for a message
    user_input = input("Enter a message to check: ")
    
    # 5. Check if the user wants to quit
    if user_input.lower() == 'exit':
        print("Goodbye!")
        break
    
    # 6. Classify the message and print the result
    result = classify_message(user_input)
    print(f"Prediction: {result}\n")